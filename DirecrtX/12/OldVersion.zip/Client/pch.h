#pragma once

#pragma comment(lib, "Engine.lib")

#include "EnginePch.h"
